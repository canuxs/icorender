Thanks for downloading!

Extract the .zip before using the app.

You must have Python app.