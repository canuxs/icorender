import os
import shutil
import json
import zipfile
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import ctypes
import sys

def set_console_icon(icon_path="icon.ico"):
    """
    Sets the icon for the Windows Console window and Taskbar if available.
    """
    if not os.path.exists(icon_path):
        return
    try:
        app_id = "icorender.packager.app.1.0"
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(app_id)
        hwnd = ctypes.windll.kernel32.GetConsoleWindow()
        if hwnd:
            h_icon = ctypes.windll.user32.LoadImageW(
                None, icon_path, 1, 0, 0, 0x0010
            )
            if h_icon:
                ctypes.windll.user32.SendMessageW(hwnd, 0x0080, 0, h_icon)
                ctypes.windll.user32.SendMessageW(hwnd, 0x0080, 1, h_icon)
    except Exception:
        pass

def register_file_association():
    """
    Registers .icopack extension with Windows Registry under HKCU safely,
    bypassing protected FileExts locks, and restarts Explorer.
    """
    if os.name != 'nt':
        return False
    try:
        import winreg
        
        icon_path = os.path.abspath("icon.ico")
        if not os.path.exists(icon_path):
            messagebox.showerror("Error", f"'icon.ico' was not found at:\n{icon_path}\nPlease place 'icon.ico' in the same folder as this script/exe.")
            return False

        # Safely try to clear FileExts cache (ignore WinError 5 access denied permissions)
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.icopack\UserChoice")
        except Exception:
            pass
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.icopack")
        except Exception:
            pass

        # 1. Extension association
        ext_key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\.icopack")
        winreg.SetValue(ext_key, "", winreg.REG_SZ, "Icorender.PackFile")
        winreg.CloseKey(ext_key)

        # 2. ProgID definition
        progid_key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\Icorender.PackFile")
        winreg.SetValue(progid_key, "", winreg.REG_SZ, "Icorender Package File")
        winreg.CloseKey(progid_key)

        # 3. Set file icon with explicit index (,0)
        icon_key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\Icorender.PackFile\DefaultIcon")
        winreg.SetValue(icon_key, "", winreg.REG_SZ, f'"{icon_path}",0')
        winreg.CloseKey(icon_key)

        # 4. Set open command
        if getattr(sys, 'frozen', False):
            command = f'"{sys.executable}" "%1"'
        else:
            script_path = os.path.abspath(sys.argv[0])
            command = f'"{sys.executable}" "{script_path}" "%1"'

        cmd_key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\Icorender.PackFile\shell\open\command")
        winreg.SetValue(cmd_key, "", winreg.REG_SZ, command)
        winreg.CloseKey(cmd_key)

        # 5. Notify Windows shell
        ctypes.windll.shell32.SHChangeNotify(0x08000000, 0x0000, None, None)

        # 6. Restart Windows Explorer to force icon cache refresh
        os.system("taskkill /f /im explorer.exe & start explorer.exe")

        return True
    except Exception as e:
        print(f"Registry error: {e}")
        return False

class IcorenderPackagerApp:
    def __init__(self, root, initial_file=None):
        self.root = root
        self.root.title("Icorender Packager & Manager")
        self.root.geometry("560x700")
        self.root.resizable(False, False)

        self.dll_path = ""
        self.icon_path = ""
        self.thumbnail_paths = []

        self.opened_pack_path = ""
        self.extracted_temp_dir = os.path.join("temp", "IcorenderPackager", "viewed_package")
        self.loaded_meta = {}

        self.create_widgets()

        if initial_file and os.path.exists(initial_file):
            self.notebook.select(1)
            self.load_icopack_file(initial_file)

    def create_widgets(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=10, pady=10)

        self.tab_create = ttk.Frame(self.notebook)
        self.notebook.add(self.tab_create, text="  Create Package  ")
        self.setup_create_tab()

        self.tab_open = ttk.Frame(self.notebook)
        self.notebook.add(self.tab_open, text="  Open .icopack  ")
        self.setup_open_tab()

    def setup_create_tab(self):
        tk.Label(self.tab_create, text="Create New .icopack", font=("Arial", 14, "bold")).pack(pady=10)

        meta_frame = tk.LabelFrame(self.tab_create, text=" Package Metadata ", font=("Arial", 9, "bold"), padx=10, pady=10)
        meta_frame.pack(fill="x", padx=10, pady=5)

        tk.Label(meta_frame, text="Name:", font=("Arial", 9)).grid(row=0, column=0, sticky="w", pady=4)
        self.entry_name = tk.Entry(meta_frame, width=38, font=("Arial", 9))
        self.entry_name.grid(row=0, column=1, pady=4, padx=5)

        tk.Label(meta_frame, text="Description:", font=("Arial", 9)).grid(row=1, column=0, sticky="w", pady=4)
        self.entry_desc = tk.Entry(meta_frame, width=38, font=("Arial", 9))
        self.entry_desc.grid(row=1, column=1, pady=4, padx=5)

        tk.Label(meta_frame, text="Link:", font=("Arial", 9)).grid(row=2, column=0, sticky="w", pady=4)
        self.entry_link = tk.Entry(meta_frame, width=38, font=("Arial", 9))
        self.entry_link.grid(row=2, column=1, pady=4, padx=5)

        files_frame = tk.LabelFrame(self.tab_create, text=" Package Assets & Files ", font=("Arial", 9, "bold"), padx=10, pady=10)
        files_frame.pack(fill="x", padx=10, pady=5)

        tk.Button(files_frame, text="Select project.dll", command=self.select_dll, width=20).grid(row=0, column=0, pady=5)
        self.lbl_dll = tk.Label(files_frame, text="No file selected", fg="gray", width=32, anchor="w")
        self.lbl_dll.grid(row=0, column=1, padx=5)

        tk.Button(files_frame, text="Select Icon (.ico)", command=self.select_icon, width=20).grid(row=1, column=0, pady=5)
        self.lbl_icon = tk.Label(files_frame, text="No file selected", fg="gray", width=32, anchor="w")
        self.lbl_icon.grid(row=1, column=1, padx=5)

        tk.Button(files_frame, text="Select Thumbnails", command=self.select_thumbnails, width=20).grid(row=2, column=0, pady=5)
        self.lbl_thumbs = tk.Label(files_frame, text="0 files selected", fg="gray", width=32, anchor="w")
        self.lbl_thumbs.grid(row=2, column=1, padx=5)

        tk.Button(
            self.tab_create, 
            text="EXPORT .icopack", 
            command=self.export_package, 
            bg="#6aa84f", 
            fg="white", 
            font=("Arial", 11, "bold"), 
            width=26, 
            height=2
        ).pack(pady=15)

    def setup_open_tab(self):
        tk.Label(self.tab_open, text="Open & Inspect .icopack", font=("Arial", 14, "bold")).pack(pady=10)

        select_frame = tk.Frame(self.tab_open)
        select_frame.pack(fill="x", padx=10, pady=5)

        tk.Button(select_frame, text="Browse .icopack", command=self.open_icopack_dialog, width=18, bg="#4a86e8", fg="white", font=("Arial", 9, "bold")).pack(side="left", padx=5)
        self.lbl_opened_pack = tk.Label(select_frame, text="No package loaded", fg="gray", anchor="w", width=35)
        self.lbl_opened_pack.pack(side="left", padx=5)

        self.inspect_frame = tk.LabelFrame(self.tab_open, text=" Package Contents & Info ", font=("Arial", 9, "bold"), padx=10, pady=10)
        self.inspect_frame.pack(fill="both", expand=True, padx=10, pady=10)

        self.txt_info = tk.Text(self.inspect_frame, height=12, width=58, font=("Consolas", 9), bg="#f9f9f9", fg="#222222")
        self.txt_info.pack(side="left", fill="both", expand=True)
        self.txt_info.config(state="disabled")

        scrollbar = tk.Scrollbar(self.inspect_frame, command=self.txt_info.yview)
        scrollbar.pack(side="right", fill="y")
        self.txt_info.config(yscrollcommand=scrollbar.set)

        btn_frame = tk.Frame(self.tab_open)
        btn_frame.pack(fill="x", padx=10, pady=5)

        tk.Button(
            btn_frame, 
            text="EXTRACT CONTENTS", 
            command=self.extract_loaded_package, 
            bg="#e06666", 
            fg="white", 
            font=("Arial", 9, "bold"), 
            width=22, 
            height=2
        ).pack(side="left", padx=5)

        tk.Button(
            btn_frame, 
            text="Register .icopack with Windows", 
            command=self.handle_association, 
            bg="#8e7cc3", 
            fg="white", 
            font=("Arial", 9, "bold"), 
            width=26, 
            height=2
        ).pack(side="right", padx=5)

    def select_dll(self):
        path = filedialog.askopenfilename(title="Select project.dll", filetypes=[("DLL files", "*.dll"), ("All files", "*.*")])
        if path:
            self.dll_path = path
            self.lbl_dll.config(text=os.path.basename(path), fg="black")

    def select_icon(self):
        path = filedialog.askopenfilename(title="Select Package Icon", filetypes=[("ICO files", "*.ico"), ("All files", "*.*")])
        if path:
            self.icon_path = path
            self.lbl_icon.config(text=os.path.basename(path), fg="black")

    def select_thumbnails(self):
        paths = filedialog.askopenfilenames(title="Select Thumbnails", filetypes=[("Image files", "*.png *.jpg *.jpeg *.ico"), ("All files", "*.*")])
        if paths:
            self.thumbnail_paths = list(paths)
            self.lbl_thumbs.config(text=f"{len(paths)} files selected", fg="black")

    def export_package(self):
        name = self.entry_name.get().strip()
        if not name:
            messagebox.showerror("Error", "Please enter a package name.")
            return
        if not self.dll_path or not os.path.exists(self.dll_path):
            messagebox.showerror("Error", "Please select a valid project.dll file.")
            return
        if not self.icon_path or not os.path.exists(self.icon_path):
            messagebox.showerror("Error", "Please select a valid package icon (.ico).")
            return

        try:
            base_temp = os.path.join("temp", "IcorenderPackager")
            working_dir = os.path.join(base_temp, "working")
            exports_dir = os.path.join(base_temp, "exports")

            if os.path.exists(working_dir):
                shutil.rmtree(working_dir)
            os.makedirs(working_dir)
            os.makedirs(exports_dir, exist_ok=True)

            meta_data = {
                "name": name,
                "description": self.entry_desc.get().strip(),
                "link": self.entry_link.get().strip()
            }
            with open(os.path.join(working_dir, "meta.json"), "w", encoding="utf-8") as f:
                json.dump(meta_data, f, indent=4, ensure_ascii=False)

            shutil.copy2(self.dll_path, os.path.join(working_dir, "project.dll"))
            shutil.copy2(self.icon_path, os.path.join(working_dir, "icon.ico"))

            if self.thumbnail_paths:
                thumbs_dest_dir = os.path.join(working_dir, "thumbnails")
                os.makedirs(thumbs_dest_dir, exist_ok=True)
                for t_path in self.thumbnail_paths:
                    shutil.copy2(t_path, thumbs_dest_dir)

            safe_name = "".join(c for c in name if c.isalnum() or c in (' ', '_', '-')).strip().replace(' ', '_')
            output_filename = f"{safe_name}.icopack"
            output_path = os.path.join(exports_dir, output_filename)

            with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for root_dir, dirs, files in os.walk(working_dir):
                    for file in files:
                        file_path = os.path.join(root_dir, file)
                        arcname = os.path.relpath(file_path, working_dir)
                        zipf.write(file_path, arcname)

            shutil.rmtree(working_dir)
            messagebox.showinfo("Success", f"Package successfully exported to:\n{output_path}")

        except Exception as e:
            messagebox.showerror("Error", f"An error occurred during export:\n{e}")

    def open_icopack_dialog(self):
        path = filedialog.askopenfilename(title="Open .icopack Package", filetypes=[("Icorender Pack files", "*.icopack"), ("Zip archives", "*.zip"), ("All files", "*.*")])
        if path:
            self.load_icopack_file(path)

    def load_icopack_file(self, path):
        self.opened_pack_path = path
        self.lbl_opened_pack.config(text=os.path.basename(path), fg="black")

        try:
            if os.path.exists(self.extracted_temp_dir):
                shutil.rmtree(self.extracted_temp_dir)
            os.makedirs(self.extracted_temp_dir, exist_ok=True)

            with zipfile.ZipFile(path, 'r') as zipf:
                zipf.extractall(self.extracted_temp_dir)

            meta_file = os.path.join(self.extracted_temp_dir, "meta.json")
            if os.path.exists(meta_file):
                with open(meta_file, "r", encoding="utf-8") as f:
                    self.loaded_meta = json.load(f)
            else:
                self.loaded_meta = {"name": "Unknown", "description": "No metadata found.", "link": ""}

            files_found = []
            for root_dir, dirs, files in os.walk(self.extracted_temp_dir):
                for file in files:
                    rel = os.path.relpath(os.path.join(root_dir, file), self.extracted_temp_dir)
                    files_found.append(rel)

            info_text = f"=== PACKAGE OVERVIEW ===\n"
            info_text += f"File: {os.path.basename(path)}\n\n"
            info_text += f"[Metadata]\n"
            info_text += f" - Name        : {self.loaded_meta.get('name', '')}\n"
            info_text += f" - Description : {self.loaded_meta.get('description', '')}\n"
            info_text += f" - Link        : {self.loaded_meta.get('link', '')}\n\n"
            info_text += f"[Contained Files ({len(files_found)})]\n"
            for f_item in files_found:
                info_text += f" • {f_item}\n"

            self.txt_info.config(state="normal")
            self.txt_info.delete("1.0", tk.END)
            self.txt_info.insert(tk.END, info_text)
            self.txt_info.config(state="disabled")

        except Exception as e:
            messagebox.showerror("Error", f"Failed to read .icopack file:\n{e}")

    def extract_loaded_package(self):
        if not self.opened_pack_path or not os.path.exists(self.extracted_temp_dir):
            messagebox.showwarning("Warning", "Please open a valid .icopack file first.")
            return

        dest_dir = filedialog.askdirectory(title="Select Destination Folder to Extract")
        if dest_dir:
            try:
                pack_name = os.path.splitext(os.path.basename(self.opened_pack_path))[0]
                target_folder = os.path.join(dest_dir, f"{pack_name}_extracted")
                
                if os.path.exists(target_folder):
                    shutil.rmtree(target_folder)
                
                shutil.copytree(self.extracted_temp_dir, target_folder)
                messagebox.showinfo("Success", f"Package successfully extracted to:\n{target_folder}")
            except Exception as e:
                messagebox.showerror("Error", f"Extraction failed:\n{e}")

    def handle_association(self):
        success = register_file_association()
        if success:
            messagebox.showinfo("Success", "`.icopack` successfully registered with Windows!")

if __name__ == "__main__":
    set_console_icon("icon.ico")
    initial_file = sys.argv[1] if len(sys.argv) > 1 else None
    root = tk.Tk()
    app = IcorenderPackagerApp(root, initial_file=initial_file)
    root.mainloop()
