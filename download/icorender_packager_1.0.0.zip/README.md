# READ ME!

- Thanks for downloading!

- Extract the .zip before using the app.

- You must have Python app.

- This app is depeloping for Windows. It maybe work in Linux or MacBook, but Windows is the best.