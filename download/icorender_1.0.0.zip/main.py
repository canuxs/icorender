import os
import shutil
import subprocess
import sys
import ctypes
from datetime import datetime

def set_console_icon(icon_path="icon.ico"):
    """
    Sets the icon for the Windows Console window and Taskbar.
    """
    if not os.path.exists(icon_path):
        return

    try:
        # Prevent Windows from grouping this process under generic 'python.exe' on the taskbar
        app_id = "icorender.cli.app.1.0"
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(app_id)

        # Get the handle of the current console window
        hwnd = ctypes.windll.kernel32.GetConsoleWindow()
        if hwnd:
            # Load icon (IMAGE_ICON = 1, LR_LOADFROMFILE = 0x0010)
            h_icon = ctypes.windll.user32.LoadImageW(
                None, icon_path, 1, 0, 0, 0x0010
            )
            
            if h_icon:
                # WM_SETICON = 0x0080 (0 = ICON_SMALL, 1 = ICON_BIG)
                ctypes.windll.user32.SendMessageW(hwnd, 0x0080, 0, h_icon)  # Title bar icon
                ctypes.windll.user32.SendMessageW(hwnd, 0x0080, 1, h_icon)  # Taskbar icon
    except Exception:
        pass  # Ignore if Win32 API calls fail (e.g., on non-Windows platforms)

class IcorenderCLI:
    def __init__(self):
        self.assets_dir = "assets"
        self.backups_dir = "backups"
        self.project_dll = "project.dll"
        
        # Check for required directories and create them if they do not exist
        if not os.path.exists(self.assets_dir):
            os.makedirs(self.assets_dir)
        if not os.path.exists(self.backups_dir):
            os.makedirs(self.backups_dir)

    def run(self):
        print("========================================")
        print("  Icorender - Icon to DLL Compiler")
        print("  Type 'help' for available commands.")
        print("========================================")
        
        while True:
            try:
                cmd_input = input("icorender> ").strip()
                if not cmd_input:
                    continue
                
                parts = cmd_input.split()
                command = parts[0].lower()

                if command == "add":
                    if len(parts) < 2:
                        print("Error: Please provide a filename. Usage: add <filename>")
                    else:
                        self.add_icon(parts[1])
                elif command == "backup":
                    self.handle_backup(parts[1:])
                elif command == "tools":
                    self.run_tools()
                elif command == "help":
                    self.show_help()
                elif command == "exit":
                    print("Exiting Icorender...")
                    break
                else:
                    print("Unknown command. Type 'help' for assistance.")
            except Exception as e:
                print(f"Error: {e}")

    def run_tools(self):
        """Launches the external tools.py script."""
        tools_script = "tools.py"
        if not os.path.exists(tools_script):
            print(f"Error: '{tools_script}' was not found in the current directory.")
            return

        print(f"Launching {tools_script}...")
        try:
            # Executes tools.py using the current Python interpreter
            subprocess.run([sys.executable, tools_script])
        except Exception as e:
            print(f"Failed to run '{tools_script}': {e}")

    def add_icon(self, filename):
        if not filename.lower().endswith(".ico"):
            print("Error: Only .ico files are supported.")
            return
        
        source = os.path.join(self.assets_dir, filename)
        if not os.path.exists(source):
            print(f"Error: '{filename}' not found in the '{self.assets_dir}/' folder.")
            return
            
        # Read the .ico file data and append it to project.dll
        with open(source, 'rb') as f_icon:
            data = f_icon.read()
            with open(self.project_dll, 'ab') as f_dll:
                f_dll.write(data)
        print(f"Successfully added '{filename}' to '{self.project_dll}'.")

    def handle_backup(self, args):
        if not os.path.exists(self.project_dll):
            print("Error: 'project.dll' does not exist yet. Add some icons first.")
            return

        if not args:
            # Standard backup using today's date (YYYY-MM-DD.dll)
            timestamp = datetime.now().strftime("%Y-%m-%d")
            dest = os.path.join(self.backups_dir, f"{timestamp}.dll")
            shutil.copy2(self.project_dll, dest)
            print(f"Backup created successfully: {dest}")
        elif len(args) >= 3 and args[0] == "." and args[1].lower() == "name":
            # Custom named backup: backup . name <filename>
            custom_name = args[2]
            if not custom_name.endswith(".dll"):
                custom_name += ".dll"
            dest = os.path.join(self.backups_dir, custom_name)
            shutil.copy2(self.project_dll, dest)
            print(f"Backup created successfully: {dest}")
        else:
            print("Invalid backup syntax. Usage: backup OR backup . name <filename>")

    def show_help(self):
        print("\nAvailable Commands:")
        print("  add <filename>           - Adds an icon from the assets folder to project.dll")
        print("  backup                   - Backs up project.dll as YYYY-MM-DD.dll in backups/")
        print("  backup . name <name>     - Backs up project.dll as <name>.dll in backups/")
        print("  tools                    - Executes the tools.py script")
        print("  help                     - Shows this help message")
        print("  exit                     - Closes the application\n")

if __name__ == "__main__":
    # Set the taskbar and title bar icon before launching the CLI
    set_console_icon("icon.ico")
    
    IcorenderCLI().run()
